import { suggestAirports } from './server-js/airports.js';

async function run(query) {
  try {
    const result = await suggestAirports(query);
    console.log(query, '=>', Array.isArray(result) ? result.length : typeof result, JSON.stringify(result).slice(0, 400));
  } catch (error) {
    console.error(query, 'ERR', error?.stack || String(error));
  }
}

await run('nyc');
await run('JFK');
